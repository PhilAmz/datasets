# from langchain.document_loaders import DirectoryLoader, BSHTMLLoader
# directory = '/home/philippe/work/repo/ChatGPT/Documents'
#
# def load_docs(directory):
#   loader = DirectoryLoader(directory,glob="*.html",loader_cls=BSHTMLLoader)
#   documents = loader.load()
#   return documents
#
# documents = load_docs(directory)
# len(documents)


from typing import List, Optional
from langchain.chat_models import ChatOpenAI
from langchain.chat_models.base import SimpleChatModel, BaseMessage
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage
)
from langchain import PromptTemplate, LLMChain
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    AIMessagePromptTemplate,
    HumanMessagePromptTemplate,
)


chat = ChatOpenAI(temperature=0, model_name="gpt-3.5-turbo",
    openai_api_key="XXXXXXXX")

x = chat([HumanMessage(content="Translate this sentence from English to French. I love programming.")])

class MyChatLLM(SimpleChatModel):
    def _call(self, messages: List[BaseMessage], stop: Optional[List[str]] = None) -> str:
        return f"Hello {len(messages)}"

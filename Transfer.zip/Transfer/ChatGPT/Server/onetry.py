import gradio as gr
import time

def check_input(text):
    if text.strip() == "":
        return "Please enter some text."
    else:
        return text


def flypaper_textbox(label="Enter some text", placeholder="Type something here"):
    textbox = gr.inputs.Textbox(label=label, placeholder=placeholder)

    def submit():
        textbox.submit()

    return gr.Interface(fn=check_input, inputs=textbox, outputs=gr.outputs.Textbox(), live=False, capture_session=True).customize(
        input_component_placeholder=placeholder,
        input_component_submit_button_text="Submit",
        input_component_submit_fly_icon="https://img.icons8.com/material-sharp/24/000000/paper-plane.png",
        input_component_submit_fly_on_click=submit,
        input_component_submit_fly_position="right",
    )

textbox = flypaper_textbox()
output = gr.outputs.Textbox()

gr.Interface(fn=check_input, inputs=textbox, outputs=output).launch()

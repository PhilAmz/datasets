import openai
import gradio as gr
from chatbot_gradio_modified_chatbot import Chatbot
import logging

logger = logging.getLogger(__name__)

start_sequence = "\AI:"
restart_sequence = "\Human:"

prompt = " "

def generate_response(prompt):
    logger.info(f"id = {id(demo)}")
    # completion = openai.Completion.create(
    #     model="gpt-3.5-turbo",
    #     prompt=prompt,
    #     temperature=0,
    #     max_tokens=500,
    #     top_p=1,
    #     frequency_penalty=0,
    #     presence_penalty=0,
    #     stop=[" Human:", " AI:"]
    # )
    return "Hello"


def my_chatbot(input, history):
    logger.info(f"{history}")
    history = history or []
    my_history = list(sum(history, ()))
    my_history.append(input)
    my_input = ' '.join(my_history)
    output = generate_response(my_input)
    history.append((input, output))
    return history, history


with gr.Blocks() as demo:
    gr.Markdown("""<h1><center>My Chatbot</center></h1>""")
    chatbot = Chatbot() #gr.Chatbot()
    state = gr.State()
    txt = gr.Textbox(show_label=False, placeholder="Ask me a question and press enter.").style(container=False)
    txt.submit(my_chatbot, inputs=[txt, state], outputs=[chatbot, state])

# demo.launch(share=True)
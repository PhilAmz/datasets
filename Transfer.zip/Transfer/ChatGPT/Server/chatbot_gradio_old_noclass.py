import gradio as gr
from collections import defaultdict
from chatbot_gradio_css import block_css
from chatbot_gradio_modified_chatbot import Chatbot
import logging
logger = logging.getLogger(__name__)

from typing import List, Optional
from langchain.chat_models.base import SimpleChatModel, BaseMessage
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ChatResult
)


class ChatBotState:
    message_history : List[BaseMessage] = []

    penalty_alpha = 1.1
    top_k = 50
    top_p = 0.92
    do_sample = True
    max_new_tokens = 100

    def to_chatbot(self):
        ret = []
        for message in self.message_history:
            if message.type == "human":
                ret.append([message.content, None])
            else:
                ret[-1][-1] = message.content
        return ret

    def set_penalty_alpha(self, penalty_alpha):
        self.penalty_alpha = penalty_alpha

    def set_top_k(self, top_k):
        self.top_k = int(top_k) if top_k else None

    def set_top_p(self, top_p):
        self.top_p = top_p

    def set_do_sample(self, do_sample):
        self.do_sample = do_sample

    def set_max_new_tokens(self, max_new_tokens):
        self.max_new_tokens = max_new_tokens


class MyChatLLM(SimpleChatModel):
    def _call(self, messages: List[BaseMessage], stop: Optional[List[str]] = None) -> str:
        return f"Hello {len(messages)}"

    async def _agenerate(
            self, messages: List[BaseMessage], stop: Optional[List[str]] = None
    ) -> ChatResult:
        return ChatResult()


chat_llm = MyChatLLM()




def generate_output(self, user_input):
    if user_input == "":
        return "Enter a valid prompt"

    generation_config = self.model.generation_config()
    generation_config.penalty_alpha = self.penalty_alpha
    generation_config.top_k = self.top_k
    generation_config.top_p = self.top_p
    generation_config.do_sample = self.do_sample
    generation_config.max_new_tokens = self.max_new_tokens

    print(f"Prompt:{user_input}, Params:{str(generation_config)}")

    try:
        return self.model.generate(texts=[user_input])
    except Exception as e:
        print(str(e))
        return "Error generating output. Please try again."



# Function for event handling
# def regenerate(self, state, request: gr.Request):
#     logger.info(f"regenerate: {request.client.host}")
#     state.messages[-1][-1] = None
#     state.skip_next = False
#     return (state, state.to_gradio_chatbot(), "") + (self.disable_btn,) * 5




# Create GRADIO Interface


main_page = gr.Blocks(  title = "ChatGPT LLM",
                        theme = gr.themes.Base(),
                        css   = block_css
                        ) #"footer {visibility: hidden}")


with main_page:

    # gr.Markdown("<h1 style='text-align: center; margin-bottom: 1rem'>"+ """ChatGPT LLM"""+ "</h1>")

    gr.Markdown('''<html>
                        <head>
                            <title>Centered Box</title>
                            <style>
                                .box {
                                    margin: 0 auto;
                                    padding: 20px;
                                    background-color: #f0f0f0;
                                    border: 2px solid #ccc;
                                    width: 100%;
                                    text-align: center;
                                }
                                .title {
                                    font-size: 24px;
                                    font-weight: bold;
                                    margin-bottom: 20px;
                                }
                            </style>
                        </head>
                        <body>
                            <div class="box">
                                <h1 class="title">ChatGPT LLM</h1>
                                <p>This is an interface to play with chatgpt.</p>
                            </div>
                        </body>
                        </html>
                        ''')

    main_row = gr.Row()

    with main_row:
        state = gr.State(ChatBotState())

        left_column = gr.Column(scale=1, min_width=150)

        #####################
        # LEFT COLUMN PART  #
        #####################
        with left_column:

            with gr.Row(elem_id="model_selector_row"):
                model_selector = gr.Dropdown(
                    # elem_id="model_selector_dropdown",
                    choices=['ModelA', 'ModelB'],
                    value='ModelA',
                    interactive=True,
                    show_label=False,
                    elem_classes="size24",
                ).style(container=False)


            with gr.Accordion("Generation Parameters", open=False, visible=True) as parameter_row:

            # gr.Markdown(
            #     """
            #     # Parameters
            #     """
            # )
            # All the parameters
                decoding_method_radio = gr.Radio(
                    label="Decoding method",
                    choices=["Top-p sampling", "Contrastive search"],
                    value="Top-p sampling",
                )

                with gr.Column(visible=False) as contrstive_search_column:
                    penalty_alpha = gr.Slider(
                        0,
                        1,
                        value=0.6,
                        label="Penalty alpha",
                        interactive=True,
                        # info="Choose between 0 and 1",
                    )
                    penalty_alpha.release(lambda penalty_alpha: state.value.set_penalty_alpha(penalty_alpha),penalty_alpha,)
                    top_k = gr.Slider(
                        1,
                        40,
                        value=4,
                        label="Top-k",
                        interactive=True,
                        # info="Choose between 1 and 40",
                    )
                    top_k.release(lambda top_k: state.value.set_top_k(top_k), top_k)
                    max_new_tokens = gr.Slider(
                        1,
                        512,
                        value=state.value.max_new_tokens,
                        label="MaxTok",
                        interactive=True,
                        # info="Choose between 1 and 512",
                    )
                    max_new_tokens.release(lambda max_new_tokens: state.value.set_max_new_tokens(max_new_tokens),max_new_tokens,)

                with gr.Column(visible=True) as top_p_sampling_column:
                    top_k = gr.Slider(
                        0,
                        40,
                        value=0,
                        label="Top-k",
                        interactive=False,
                        # info="Always zero",
                        visible=False,
                    )
                    top_k.release(lambda top_k: state.value.set_top_k(top_k), top_k)

                    top_p = gr.Slider(
                        0,
                        1,
                        value=0.92,
                        label="Top-p",
                        interactive=True,
                        # info="Choose between 0 and 1",
                    )
                    top_p.release(lambda top_p: state.value.set_top_p(top_p), top_p)

                    gr.Radio(
                        label="Do sample",
                        interactive=False,
                        choices=[True, False],
                        value=True,
                        visible=False,
                    )
                    max_new_tokens2 = gr.Slider(
                        1,
                        512,
                        value=state.value.max_new_tokens,
                        label="MaxTok",
                        interactive=True,
                        # info="Choose between 1 and 512",
                    )
                    max_new_tokens2.release(lambda max_new_tokens: state.value.set_max_new_tokens(max_new_tokens),max_new_tokens2,)

                def handle_decoding_method_change(decoding_method_radio):
                    if decoding_method_radio == "Top-p sampling":
                        state.value.set_top_k(0)
                        state.value.set_do_sample(True)
                        state.value.set_top_p(0.92)
                        state.value.set_penalty_alpha(None)
                        return (
                            gr.update(visible=True),
                            gr.update(visible=False),
                            gr.update(value=0),
                            gr.update(value=0.92),
                            gr.update(value=0),
                            gr.update(value=state.value.max_new_tokens),
                            gr.update(value=state.value.max_new_tokens),
                        )
                    else:
                        state.value.set_top_k(4)
                        state.value.set_do_sample(False)
                        state.value.set_top_p(1)
                        state.value.set_penalty_alpha(0.6)
                        return (
                            gr.update(visible=False),
                            gr.update(visible=True),
                            gr.update(value=4),
                            gr.update(value=1),
                            gr.update(value=0.6),
                            gr.update(value=state.value.max_new_tokens),
                            gr.update(value=state.value.max_new_tokens),
                        )

                decoding_method_radio.change(
                    handle_decoding_method_change,
                    decoding_method_radio,
                    [
                        top_p_sampling_column,
                        contrstive_search_column,
                        top_k,
                        top_p,
                        penalty_alpha,
                        max_new_tokens,
                        max_new_tokens2,
                    ],
                    show_progress=True,
                )

        #####################
        # RIGHT COLUMN PART #
        #####################
        right_column = gr.Column(scale=4, min_width=600)
        with right_column:

            # gr.Markdown("""### Main Chat""")

            chatbot = Chatbot(label="chatbot", elem_id="chatbot", visible=True).style(height=550)

            with gr.Row() as text_box_row:
                with gr.Column(scale=20):
                    msg = gr.Textbox(
                        show_label=False,
                        placeholder="Enter text and press Send",
                    ).style(container=False)
                with gr.Column(scale=1, min_width=50):
                    send_btn = gr.Button(value="Send", visible=True)

            with gr.Row() as button_row:
                # upvote_btn = gr.Button(value="👍  Upvote", interactive=True)
                # downvote_btn = gr.Button(value="👎  Downvote", interactive=True)
                regenerate_btn = gr.Button(value="🔄  Regenerate", interactive=True)
                clear_btn = gr.Button(value="🗑️  Clear history", interactive=True)


    # Define the logic between elements
    # regenerate_btn.click(self.regenerate, state, [state, chatbot, textbox] + btn_list).then(
    #     http_bot,
    #     [state, model_selector, temperature, max_output_tokens],
    #     [state, chatbot] + btn_list,
    # )
    def clear_history(state, request: gr.Request):
        logger.info(f"clear history: ip: {request.client.host}")
        state.message_history = []
        return (state, [], "")

    clear_btn.click(clear_history, state, [state, chatbot, msg])

    def user_send_msg(state, user_message):
        if state is None:
            state = ChatBotState()
        state.message_history.append(HumanMessage(content=user_message))

        return state, "", state.to_chatbot()

    def ai_answer_and_send_msg(state):
        ai_answer = chat_llm(state.message_history)

    #         # Pass user input to the model
    #         ai_message = '''```js
    # var foo = function (bar) {
    #   return bar++;
    # };
    # console.log(foo(5));
    # ```'''  # "🤖 : Hello" #+ self.generate_output(history[-1][0])[0]

        state.message_history.append(ai_answer)
        return state, state.to_chatbot()

    msg.submit(user_send_msg, [state, msg], [state, msg, chatbot]).then(ai_answer_and_send_msg, state, [state,chatbot])



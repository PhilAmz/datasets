import gradio as gr
from collections import defaultdict
from chatbot_gradio_css import block_css
from chatbot_gradio_modified_chatbot import Chatbot
import logging
logger = logging.getLogger(__name__)

from typing import List, Optional
from langchain.chat_models.base import SimpleChatModel, BaseMessage
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ChatResult
)


class ChatBotState:
    message_history : List[BaseMessage] = None

    def to_chatbot(self):
        ret = []
        for message in self.message_history:
            if message.type == "human":
                ret.append([message.content, None])
            else:
                ret[-1][-1] = message.content
        return ret

    def __str__(self):
        return f'''
        ChatBotState : {id(self)}
        - message_history : {self.message_history}
        '''


class MyChatLLM(SimpleChatModel):
    def _call(self, messages: List[BaseMessage], stop: Optional[List[str]] = None) -> str:

#         return '''```js
#             var ai = function (bar) {
#               return bar++;
#             };
#             console.log(foo(5));
#             ```''' if ((len(messages)-1)/2)%2==0 else '''``` python
# from pydantic import BaseModel, Field , validator
#
# class AA(BaseModel):
#   datasource : str = Field(...,descrition='...',example=',,,,')
#
# @validator('datasource')
# def data_source_match(cls,value)
#  if value not in []
#   raise valueError()
#  return value
#
#
# ``` '''
        import numpy as np
        return f"Hello {len(messages)} + {np.random.random(1)}"

    async def _agenerate(
            self, messages: List[BaseMessage], stop: Optional[List[str]] = None
    ) -> ChatResult:
        return ChatResult()


chat_llm = MyChatLLM()





# Function for event handling
# def regenerate(self, state, request: gr.Request):
#     logger.info(f"regenerate: {request.client.host}")
#     state.messages[-1][-1] = None
#     state.skip_next = False
#     return (state, state.to_gradio_chatbot(), "") + (self.disable_btn,) * 5




# Create GRADIO Interface


with gr.Blocks(  title = "ChatGPT LLM",
                        theme = gr.themes.Base(),
                        css   = block_css
                        ) as main_page:

    # gr.Markdown("<h1 style='text-align: center; margin-bottom: 1rem'>"+ """ChatGPT LLM"""+ "</h1>")

    gr.Markdown('''<html>
                        <head>
                            <title>Centered Box</title>
                            <style>
                                .box {
                                    margin: 0 auto;
                                    padding: 20px;
                                    background-color: #f0f0f0;
                                    border: 2px solid #ccc;
                                    width: 100%;
                                    text-align: center;
                                }
                                .title {
                                    font-size: 24px;
                                    font-weight: bold;
                                    margin-bottom: 20px;
                                }
                            </style>
                        </head>
                        <body>
                            <div class="box">
                                <h1 class="title">ChatGPT LLM</h1>
                                <p>This is an interface to play with chatgpt.</p>
                            </div>
                        </body>
                        </html>
                        ''')


    with gr.Row() as main_row:

        #####################
        # LEFT COLUMN PART  #
        #####################
        with gr.Column(scale=1, min_width=150) as left_column:

            with gr.Row(elem_id="model_selector_row"):
                model_selector = gr.Dropdown(
                    # elem_id="model_selector_dropdown",
                    choices=['ModelA', 'ModelB'],
                    value='ModelA',
                    interactive=True,
                    show_label=False,
                    elem_classes="size24",
                ).style(container=False)


            with gr.Accordion("Generation Parameters", open=False, visible=True) as parameter_row:

                    do_sample = gr.Checkbox(
                        value = True,
                        label="Do sample",
                        interactive=True,
                        visible=True,
                    )

                    temperature = gr.Slider(
                        minimum=0.0,
                        maximum=1.0,
                        value=0.7,
                        step=0.1,
                        interactive=True,
                        label="Temp",
                    )
                    max_tokens = gr.Slider(
                        minimum=0,
                        maximum=1024,
                        value=512,
                        step=64,
                        interactive=True,
                        label="Maxtok",
                    )

                    top_k = gr.Slider(
                        1,
                        100,
                        value=50,
                        label="Top-k",
                        interactive=True,
                    )

                    top_p = gr.Slider(
                        0,
                        1,
                        value=0.90,
                        label="Top-p",
                        interactive=True,
                    )

        #####################
        # RIGHT COLUMN PART #
        #####################
        with gr.Column(scale=4, min_width=600) as right_column:

            chatbot = Chatbot(label="chatbot", elem_id="chatbot", visible=True).style(height=550)
            state = gr.State()

            with gr.Row() as text_box_row:
                with gr.Column(scale=20):
                    msg_textbox = gr.Textbox(
                        show_label=False,
                        placeholder="Enter text and press Send or Enter",
                    ).style(container=False)
                with gr.Column(scale=1, min_width=50):
                    send_msg_btn = gr.Button(value="Send", visible=True)

            with gr.Row() as button_row:
                # upvote_btn = gr.Button(value="👍  Upvote", interactive=True)
                # downvote_btn = gr.Button(value="👎  Downvote", interactive=True)
                regenerate_btn = gr.Button(value="🔄  Regenerate", interactive=True)
                clear_btn = gr.Button(value="🗑️  Clear history", interactive=True)

    model_param_list = [model_selector, do_sample, temperature, max_tokens, top_k, top_p]

    # Define the logic between elements

    def regenerate(state, request: gr.Request):
        logger.info(f"regenerate. ip: {request.client.host}")
        if state is None:
            state = ChatBotState()
            state.message_history = []

        state.message_history = state.message_history[0:-1]
        return  state, state.to_chatbot()


    def clear_history(state, request: gr.Request):

        logger.info(f"clear history: ip: {request.client.host}")
        state.message_history = []
        return (state, [], "")

    clear_btn.click(clear_history, state, [state, chatbot, msg_textbox])

    def user_send_msg(state, user_message):
        logger.info(f'{state}')
    #     user_message = '''```js
    # var foo = function (bar) {
    #   return bar++;
    # };
    # console.log(foo(5));
    # ```'''
        if state is None:
            state = ChatBotState()
            state.message_history=[]

        if len(user_message)>0:
            state.message_history.append(HumanMessage(content=user_message))

        return state, "", state.to_chatbot()

    def ai_answer_and_send_msg(state, model_selector, do_sample, temperature, max_tokens, top_k, top_p):
        if len(state.message_history)>0:
            if state.message_history[-1].type == 'human':
                ai_answer = chat_llm(state.message_history)
                state.message_history.append(ai_answer)
            return state, state.to_chatbot()
        else:
            return state, []

    msg_textbox.submit(user_send_msg, [state, msg_textbox], [state, msg_textbox, chatbot]).then(ai_answer_and_send_msg, [state] + model_param_list, [state,chatbot])
    send_msg_btn.click(user_send_msg, [state, msg_textbox], [state, msg_textbox, chatbot]).then(ai_answer_and_send_msg, [state] + model_param_list, [state,chatbot])
    regenerate_btn.click(regenerate, state, [state, chatbot]).then(ai_answer_and_send_msg, [state] + model_param_list, [state,chatbot])

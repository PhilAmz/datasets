from fastapi import FastAPI, Query, Path, Request
from typing import Optional
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

m =20

app = FastAPI(  title="My Super Project",
                description="This is a very fancy project, with auto docs for the API and everything",
                version="2.5.0",

                openapi_tags= [
                    {
                        "name": "items",
                        "description": "Manage items. So _fancy_ they have their own docs.",
                        "externalDocs": {
                                            "description": "Items external docs",
                                            "url": "https://fastapi.tiangolo.com/",
                                        },
                    }
                    ],
                logger=logger)

# @app.get("/items/{item_id}")
# def read_root(item_id: str, request: Request):
#     client_host = request.client.host
#     return {"client_host": client_host, "item_id": item_id}
#
# from fastapi import BackgroundTasks, FastAPI
# import threading
# import time as kkk
# class Model(object):
#     def __init__(self):
#         self.t = threading.Thread(target=self.func)
#         self.t.start()
#         self.x = 0
#
#     def predict(self):
#         logger.info("fffff")
#         tstart = kkk.time()
#         y = 0
#         for j in range(100000000):
#             y = y + j * (j - 1)
#         logger.info(f"fffff Done in {kkk.time()-tstart}")
#
#     def func(self):
#         for i in range(10000):
#             kkk.sleep(50)
#             logger.info(f'Launching calculation Model {self.t} X={self.x}')
#             y =0
#             for j in range(100000000):
#                 y = y + j*(j-1)
#             self.x = self.x + 1
#             logger.info(f'Model {self.t} X={self.x}')
#
# serve_handle = None
#
# @app.on_event("startup") # Code to be run when the server starts.
# async def startup_event():
#     global serve_handle
#     serve_handle = Model()
#
# @app.on_event("shutdown")
# def shutdown_event():
#     logger.info("shutdown (a coder)")
#
#
# @app.get("/mygetter")
# async def myget(item_id: int):
#     import time
#     logger.info(f"myget {serve_handle.x} {serve_handle}")
#     serve_handle.predict()
#     logger.info(f"Done myget {serve_handle.x} {serve_handle}")
#
# #TODO : from https://fastapi.tiangolo.com/tutorial/security/simple-oauth2/
# from fastapi.responses import HTMLResponse, JSONResponse
# html = """
# <!DOCTYPE html>
# <html>
#     <head>
#         <title>Authorize</title>
#     </head>
#     <body>
#         <h1>WebSocket Authorize</h1>
#         <p>Token:</p>
#         <textarea id="token" rows="4" cols="50"></textarea><br><br>
#         <button onclick="websocketfun()">Send</button>
#         <ul id='messages'>
#         </ul>
#         <script>
#             const websocketfun = () => {
#                 let token = document.getElementById("token").value
#                 let ws = new WebSocket(`ws://192.168.18.202:8000/ws?token=${token}`)
#                 ws.onmessage = (event) => {
#                     let messages = document.getElementById('messages')
#                     let message = document.createElement('li')
#                     let content = document.createTextNode(event.data)
#                     message.appendChild(content)
#                     messages.appendChild(message)
#                 }
#             }
#         </script>
#     </body>
# </html>
# """
#
# @app.get("/", tags=["items"])
# async def root():
#     global m
#     # to check by calling 2 times the doc that it switch to the other threads
#     logger.info("root")
#     import time
#     # from multiprocessing import Manager
#     # manag = Manager()
#     # serviceLock = manag.Lock()
#     # serviceStatusDict = manag.dict()
#     # serviceStatusDict['aa'] = 5 if 'aa' not in serviceStatusDict.keys() else (serviceStatusDict['aa']+5)
#     # x = serviceStatusDict['aa']
#     # # serviceLock.release()
#     # time.sleep(5)
#     m = m + 5
#     logger.info(f"root Done {m}")
#     # return {"message": "Hello World"}
#     return HTMLResponse(html)
#
# @app.get("/items/{item_id}")
# def read_item(item_id: int, q: Optional[str] = None):
#     logger.info("read_item")
#     return {"item_id": item_id, "q": q}
#
# class Item(BaseModel):
#     name: str
#     description: Optional[str] = None
#     price: float
#     tax: Optional[float] = None
#
# @app.put("/items/{item_id}")
# def update_item(item_id: int, item: Item):
#     logger.info("update_item")
#     return {"item_name": item.name, "item_price":item.price, "item_id": item_id}
#
# # use response_model to have the schema of the output
# @app.post("/items/", response_model=Item, summary="My summary Create an item")
# async def create_item(item: Item):
#     """
#         Create an item with all the information:
#
#         - **name**: each item must have a name
#         - **description**: a long description
#         - **price**: required
#         - **tax**: if the item doesn't have tax, you can omit this
#         - **tags**: a set of unique tag strings for this item
#         \f
#         :param item: User input.
#         """
#     item_dict = item.dict()
#     if item.tax:
#         price_with_tax = item.price + item.tax
#         item_dict.update({"price_with_tax": price_with_tax})
#     return item_dict
#
#
# from enum import Enum
# class ModelName(str, Enum):
#     alexnet = "alexnet"
#     resnet = "resnet"
#     lenet = "lenet"
#
# @app.get("/models/{model_name}")
# async def get_model(model_name: ModelName):
#     if model_name == ModelName.alexnet:
#         return {"model_name": model_name, "message": "Deep Learning FTW!"}
#
#     if model_name.value == "lenet":
#         return {"model_name": model_name, "message": "LeCNN all the images"}
#
#     return {"model_name": model_name, "message": "Have some residuals"}
#
#
# @app.get("/items_with_query/")
# async def read_items(
#     q: Optional[str] = Query(None, min_length=3, max_length=50, regex="^fixedquery$")
# ):
#     results = {"items": [{"item_id": "Foo"}, {"item_id": "Bar"}]}
#     if q:
#         results.update({"q": q})
#     return results
#
#
# @app.put("/items_with_path/{item_id}")
# async def update_item(
#     *,
#     item_id: int = Path(..., title="The ID of the item to get", ge=0, le=1000),
#     q: Optional[str] = None,
#     item: Optional[Item] = None,
# ):
#     results = {"item_id": item_id}
#     if q:
#         results.update({"q": q})
#     if item:
#         results.update({"item": item})
#     return results
#
#
# from fastapi import Body, FastAPI
# from pydantic import BaseModel, Field
# class Item2(BaseModel):
#     name: str
#     description: Optional[str] = Field(
#         None, title="The description of the item", max_length=300
#     )
#     price: float = Field(..., gt=0, description="The price must be greater than zero")
#     tax: Optional[float] = None
#
#     class Config:
#         schema_extra = {
#             "example": {
#                 "name": "Foo",
#                 "description": "A very nice Item",
#                 "price": 35.4,
#                 "tax": 3.2,
#             }
#         }
#
# @app.put("/items_withField/{item_id}")
# async def update_item2(item_id: int, item: Item2 = Body(..., embed=True)):
#     results = {"item_id": item_id, "item": item}
#     return results


from datetime import datetime, time, timedelta
from typing import Optional

# marche pas
# @app.put("/items_datetime_uid/{item_id}")
# async def read_items(
#     item_id: int,
#     start_datetime: Optional[datetime] = Body(None),
#     end_datetime: Optional[datetime] = Body(None),
#     repeat_at: Optional[time] = Body(None),
#     process_after: Optional[timedelta] = Body(None),
# ):
#     start_process = start_datetime + process_after
#     duration = end_datetime - start_process
#     return {
#         "item_id": item_id,
#         "start_datetime": start_datetime,
#         "end_datetime": end_datetime,
#         "repeat_at": repeat_at,
#         "process_after": process_after,
#         "start_process": start_process,
#         "duration": duration,
#     }
#
# from fastapi.responses import HTMLResponse
# @app.get("/html")
# async def html_ex():
#     content = """
# <body>
# <form action="/files/" enctype="multipart/form-data" method="post">
# <input name="files" type="file" multiple>
# <input type="submit">
# </form>
# <form action="/uploadfiles/" enctype="multipart/form-data" method="post">
# <input name="files" type="file" multiple>
# <input type="submit">
# </form>
# </body>
#     """
#     return HTMLResponse(content=content)
#
#
# from fastapi import FastAPI, HTTPException
# the_items = {"foo": "The Foo Wrestlers"}
#
#
# @app.get("/items_with_error/{item_id}")
# async def read_item(item_id: str):
#     if item_id not in the_items:
#         raise HTTPException(status_code=404, detail="Item not found")
#     return {"item": the_items[item_id]}
#
#
# from fastapi import FastAPI, Response
#
# @app.post("/cookie-and-object/")
# def create_cookie(response: Response):
#     response.set_cookie(key="fakesession", value="fake-cookie-session-value")
#     return {"message": "Come to the dark side, we have cookies"}

import gradio as gr

CUSTOM_PATH = "/gradio"


@app.get("/")
def read_main():
    return {"message": "This is your main app"}

from chatbot_gradio import main_page
# from chatbot_gradio import CHATBOT_Gradio
# x = CHATBOT_Gradio(model_path ="MYMODEL")
# from ExChatbot import demo

io = gr.Interface(lambda x: "Hello, " + x + "!", "textbox", "textbox")
# app = gr.mount_gradio_app(app, x.getGradioIO(), path=CUSTOM_PATH)
app = gr.mount_gradio_app(app, main_page, path=CUSTOM_PATH)



if __name__ == "__main__":
    import uvicorn
    from Common.Utils.system_util import get_ip
    from Common.Utils.logging_utils import set_logging_default

    set_logging_default()

    uvicorn.run(app,  log_config=None, host=get_ip(), port=5000, reload=False, workers=1,access_log=False)
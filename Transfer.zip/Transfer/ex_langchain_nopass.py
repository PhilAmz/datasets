from langchain.llms import OpenAI

# initialize the models
openai = OpenAI(
    model_name="gpt-3.5-turbo",
    openai_api_key="XXXXXXX"
)

prompt = """Answer the question based on the context below. If the
question cannot be answered using the information provided answer
with "I don't know".

Context: Large Language Models (LLMs) are the latest models used in NLP.
Their superior performance over smaller models has made them incredibly
useful for developers building NLP enabled applications. These models
can be accessed via Hugging Face's `transformers` library, via OpenAI
using the `openai` library, and via Cohere using the `cohere` library.

Question: Which libraries and model providers offer LLMs?

Answer: """

print(openai(prompt))

from langchain.embeddings import HuggingFaceEmbeddings, HuggingFaceInstructEmbeddings

# BIENCODERS : Voir https://www.sbert.net/docs/pretrained_models.html
model_name = "sentence-transformers/all-mpnet-base-v2"
model_name = "sentence-transformers/multi-qa-mpnet-base-dot-v1"
model_kwargs = {'device': 'cpu'}
hf = HuggingFaceEmbeddings(model_name=model_name, model_kwargs=model_kwargs, cache_folder='/home/philippe/work/repo/LLM')

# INSTRUCTOR ENCODERS
model_name = "hkunlp/instructor-large"
DEFAULT_EMBED_INSTRUCTION = "Represent the document for retrieval: "
DEFAULT_QUERY_INSTRUCTION = "Represent the question for retrieving supporting documents: "
hf = HuggingFaceInstructEmbeddings(model_name=model_name,
                                   embed_instruction = DEFAULT_EMBED_INSTRUCTION,
                                   query_instruction=DEFAULT_QUERY_INSTRUCTION,
                                   model_kwargs=model_kwargs,
                                   cache_folder='/home/philippe/work/repo/LLM')

# CROSS ENCODER # Do that only for download for the moment
model_name = 'cross-encoder/ms-marco-MiniLM-L-12-v2'
hf = HuggingFaceEmbeddings(model_name=model_name, model_kwargs=model_kwargs, cache_folder='/home/philippe/work/repo/LLM')

hf.embed_query('play golf')



from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter, NLTKTextSplitter, RecursiveCharacterTextSplitter
from langchain.llms import OpenAI
from langchain.chains import ConversationalRetrievalChain

# To load document from all our list of loaders
from langchain.document_loaders import DirectoryLoader, BSHTMLLoader, UnstructuredURLLoader
directory = '/home/philippe/work/repo/ChatGPT/Documents'

def load_docs(directory):
  loader = DirectoryLoader(directory,glob="*.html",loader_cls=BSHTMLLoader)
  documents = loader.load()
  return documents

documents = load_docs(directory)
len(documents)



from langchain.document_loaders import TextLoader

loaders = [TextLoader("/home/philippe/work/repo/ChatGPT/Documents/A.txt")]
documents = []
for loader in loaders:
    documents.extend(loader.load())


# From urls : Need Selenium !!!
# loaders = [UnstructuredURLLoader(urls=['https://seekingalpha.com/article/4595694-sandvik-ab-publ-sdvkf-q1-2023-earnings-call-transcript', 'https://seekingalpha.com/article/4595682-bank-ozk-ozk-q1-2023-earnings-call-transcript'])]
# documents = []
# for loader in loaders:
#     documents.extend(loader.load())



# Do we need splitters in small chunkcs ?
# NLTKTextSplitter split per sentence ?
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
text_splitter = NLTKTextSplitter()
documents = text_splitter.split_documents(documents)

#s plit the documents into smaller chunks for processing. We will use the RecursiveCharacterTextSplitter from LangChain,
# which by default tries to split on the characters ["\n\n", "\n", " ", ""].
def split_docs(documents, chunk_size=1000, chunk_overlap=20):
  text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
  docs = text_splitter.split_documents(documents)
  return docs

docs = split_docs(documents)
print(len(docs))



